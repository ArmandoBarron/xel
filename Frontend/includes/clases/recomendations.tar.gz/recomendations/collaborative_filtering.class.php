<?php
include_once(dirname(__FILE__) . "/../class.DB.php");
include_once("kmeans.class.php");
include_once("prediction.class.php");

class CollaborativeFiltering{

  /**
  * ATRIBUTOS
  */

  //VARIABLES
  private $clusters_number = 3;
  private $iduser;
  private $data;
  private $recommendations;
  private $items;

  /**
  * CONSTRUCTOR
  */
  public function __construct($iduser){
    $this->iduser = $iduser;
    $this->recommendations = array();
    $this->data = $this->loadData();
  }

  /**
  * REALIZA EL PROCESO PARA OBTENER NUEVAS RECOMENDACIONES PARA EL USUARIO
  */
  public function make_recommendations($number_of_reco){
    $kmeans = new Kmeans($this->data,$this->clusters_number);
    $clusters = $kmeans->make_clusters();
    $usr_cluster = $kmeans->getCluster($this->iduser);
    if($usr_cluster->size() > 3){
      $prediction = new Prediction($this->iduser,$usr_cluster);
      foreach ($this->data[$this->iduser] as $img => $punt){
        if($punt == 0){
          $prediction->setItem($img);
          $p = $prediction->make_prediction();
          $this->recommendations[$img] = $p;
        }
      }
      arsort($this->recommendations,SORT_NUMERIC);
      $res = array_slice($this->recommendations, 0, $number_of_reco, true);
    }else{
      return array();
    }

    return $res;
  }

  /**
  * CARGA LOS DATOS DESDE LA BASE DE DATOS
  */
  function loadData(){
    $db = new DB();

    $busquedas_poligonos = $db->executeQuery("select polygon from busquedas as b inner join busquedabypolygon as bp on bp.idbusqueda = b.idbusqueda where \"user\" = $this->iduser;");
    foreach ($busquedas_poligonos as $key => $polygon) {
      $polygon = str_replace("(","", $polygon);
      $polygon = str_replace(")","", $polygon);
      $coors = explode(",",implode(",", $polygon));
      $n = count($coors);
      $sum_lat = 0;
      $sum_lon = 0;
      for($i=0;$i<$n;$i+=2){
        $sum_lon += $coors[$i];
        $sum_lat += $coors[$i+1];
      }
      $center_lat += $sum_lat/($n/2);
      $center_lon += $sum_lon/($n/2); 
    }
    $busquedas_circulos = $db->executeQuery("select center_lat,center_lon from busquedas as b inner join busquedabycircle as bp on bp.idbusqueda = b.idbusqueda where \"user\" = $this->iduser;");

    foreach($busquedas_circulos as $circle){
      $center_lat += $circle['center_lat'];
      $center_lon += $circle['center_lon'];
    }

    $busquedas_puntos = $db->executeQuery("select lat,lon from busquedas as b inner join busquedabypoint as bp on bp.idbusqueda = b.idbusqueda where \"user\" = $this->iduser;");

    foreach($busquedas_puntos as $punto){
      $center_lat += $punto['lat'];
      $center_lon += $punto['lon'];
    }

    $m = count($busquedas_poligonos) + count($busquedas_circulos) + count($busquedas_puntos);
    $center_lat /= $m;
    $center_lon /= $m;

    $number_raking = $db->executeQuery("select count(idusuario) from puntuaciones where idusuario = $this->iduser")[0][0];
    
    if($number_raking > 0){
      $users = $db->executeQuery("select distinct idusuario from puntuaciones");
      foreach ($users as $key_user => $user) {
        $ratings = $db->executeQuery("select idimagen,rating from puntuaciones as p inner join metadatos as m on m.idelemento = p.idimagen inner join points as po on po.idmetadatos = m.idmetadato and po.position = 'CENTER' where idusuario = $user[0] and point('($center_lon,$center_lat)') <-> point(''||po.lon||','||po.lat||'') < 3;");
        foreach ($ratings as $key_rating => $rate) {
          $table[$user[0]][$rate['idimagen']] = $rate['rating'];
        }
      }

      $this->items = $db->executeQuery("select distinct idimagen from puntuaciones as p inner join metadatos as m on m.idelemento = p.idimagen inner join points as po on po.idmetadatos = m.idmetadato and po.position = 'CENTER' where point('($center_lon,$center_lat)') <-> point(''||po.lon||','||po.lat||'') < 3");
      foreach ($users as $key_user => $user) {
        $j=0;
        foreach ($this->items as $key_img => $img) {
          if(isset($table[$user[0]][$img[0]])){
            $matrix[$user[0]][$img[0]] = $table[$user[0]][$img[0]];
          }else{
            $matrix[$user[0]][$img[0]] = 0;
          }
          $j++;
        }
      }
      return $matrix;
    }else{
      throw new Exception('No hay elementos.');
    }
  }
}
?>
