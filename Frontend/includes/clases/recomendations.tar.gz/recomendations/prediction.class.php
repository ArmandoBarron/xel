<?php
/**
* CLASE QUE HACE LAS PREDICCIONES DE LOS RATINGS EN BASE
* A LOS CLUSTERS GENERADOS
**/
class Prediction{
  /**
  * ATRIBUTOS
  */
  private $cluster; //cluster de usuarios
  private $user; //usuario sobre el cuál se haran las predicciones
  private $item; //item el cual será rankeado

  /**
  * CONSTRUCTORES
  */
  public function __construct($user,$cluster){
    $this->cluster = $cluster;
    $this->user = $user;
  }

  /****
  * SETTERS
  ****/
  public function setUser($user){
    $this->user = $user;
  }

  public function setItem($item){
    $this->item = $item;
  }

  public function setCluster($cluster){
    $this->cluster = $cluster;
  }

  /****
  * GETTERS
  ****/
  public function getUser(){
    return $this->user;
  }

  public function getItem(){
    return $this->item;
  }

  public function getCluster(){
    return $this->cluster;
  }

  /**
  * FUNCTIÓN QUE REALIZA LA PREDICCIÓN DE LA PUNTUACIÓN DE UN USUARIO HACIA
  * UN ITEM EN BASE A LAS PUNTUACIONES DE OTROS USUARIOS
  */
  public function make_prediction(){
    $neighbors = $this->cluster->getElements();
    $sum = 0;
    $votes = array();
    foreach ($neighbors as $key => $neighbor) {
      if($neighbor->getRating($this->item) > 0)
        $votes[$neighbor->getRating($this->item)]++;
    }

    arsort($votes,SORT_NUMERIC);
    reset($votes);

    $keys = array_keys($votes);
    $n_keys = count($keys);
    $first = $keys[0];
    $sum = $first;
    for($i=1;$i<$n_keys;$i++){
      if($votes[$first] == $votes[$keys[$i]]){
        $sum += $keys[$i];
      }else{
        if($i > 1){
          return $sum/($i);
        }
        return $first;
      }
    }
    return $first;
  }

}
?>
