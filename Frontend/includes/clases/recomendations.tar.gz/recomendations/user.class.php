 <?php
class User{

  /****
  * ATTRIBUTES
  ****/
  private $id;
  private $ratings;
  private $cluster;

  /****
  * CONSTRUCTOR
  ****/
  public function __construct($id,$ratings){
    $this->id = $id;
    $this->ratings = $ratings;
  }

  /****
  * GETTERS
  ****/
  public function getUser(){
    return $this->id;
  }

  public function getRatings(){
    return $this->ratings;
  }

  public function getRating($idimg){
    return $this->ratings[$idimg];
  }

  public function getCluster(){
    return $this->cluster;
  }

  /****
  * SETTERS
  ****/
  public function setUser($id){
    $this->id = $id;
  }

  public function setRatings($ratings){
    $this->ratings = $ratigns;
  }

  public function setRating($idimg,$rating){
    $this->rating[$idimg] = $rating;
  }

  public function setCluster($cluster){
    $this->cluster = $cluster;
  }

  /***
  * OTHER FUNCTIONS
  ***/
  /***
  * GENERA UN PUNTO CON NUMEROS RANDMOM, EN BASE A LOS VALORES MINIMOS Y
  * Y MAXIMOS RECIBIDOS, Y UTILIZA LAS DIMENSIONES COMO KEYS DE LOS ARREGLOS
  ***/
  public static function randomPoint($min,$max,$dimensions){
    foreach ($dimensions as $d) {
      $point[$d] = rand($min,$max);
    }
    return $point;
  }

  /***
  * REGRESA LOS VALORES EN FORMA DE STRING
  ***/
  public function toString(){
    $str = "USER = " . $this->id ."<br>";
    foreach ($this->ratings as $key => $rating) {
      $str .= $rating . "  ";
    }
    return $str;
  }

  /***
  * COMPARA SI EL INDICE RECIBIDO ES IGUAL AL DEL USUARIO
  ***/
  public function compare($iduser){
    return $iduser == $this->id;
  }
}
 ?>
